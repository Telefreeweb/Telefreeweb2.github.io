let focused;
exports.getFocus = () =>{
    return focused;
}

exports.setFocus = (el) =>{
    focused = el;
}