export const setPlayingChannel = (channel) => {
    return{
        type: "SET_CHANNEL",
        payload: channel
    }
}
