export const setPlaylist = (playlist) => {
    return{
        type: "SET_PLAYLIST",
        payload: playlist
    }
}
