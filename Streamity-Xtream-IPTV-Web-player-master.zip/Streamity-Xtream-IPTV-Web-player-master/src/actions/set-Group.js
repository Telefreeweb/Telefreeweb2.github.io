export const setGroupList = (groups) => {
    return{
        type: "SET_GROUP",
        payload: groups
    }
}
