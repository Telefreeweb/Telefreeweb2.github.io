export const setFullScreen = (fullscreen) => {
    return{
        type: "SET_FULLSCREEN",
        payload: fullscreen
    }
}
