export const setEpgPopup = (payload = null) => {
    return{
        type: "SET_EPG_POPUP",
        payload: payload
    }
}
