export const setTimer60 = () => {
    return{
        type: "SET_TIMER_60",
        payload: Date.now()
    }
}
