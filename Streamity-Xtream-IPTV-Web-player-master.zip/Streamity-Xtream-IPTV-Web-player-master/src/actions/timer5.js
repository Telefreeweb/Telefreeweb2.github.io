export const setTimer5 = () => {
    return{
        type: "SET_TIMER_5",
        payload: Date.now()
    }
}
