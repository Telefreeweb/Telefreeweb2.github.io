export const setPlaylistEpisodes = (playlist) => {
    return{
        type: "SET_PLAYLIST_EPISODES",
        payload: playlist
    }
}
